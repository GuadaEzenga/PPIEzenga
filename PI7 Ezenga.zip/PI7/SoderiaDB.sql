CREATE DATABASE SoderiaDB;
USE SoderiaDB;

CREATE TABLE Cliente (
    idCliente INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100),
    apellido VARCHAR(100),
    ciudad VARCHAR(100),
    direccion VARCHAR(255),
    telefono VARCHAR(20)
);

INSERT INTO Cliente (nombre, apellido, ciudad, direccion, telefono) VALUES
('Carlos', 'Lopez', 'Villa Maria', 'Mendoza 678', '3534789654'),
('Juan', 'Perez', 'Villa Maria', 'La Rioja 123', '3535789856'),
('Pedro', 'Gonzalez', 'Villa Maria', 'Catamarca 355', '3534896523'),
('Maria', 'Pedraza', 'Villa Nueva', 'Libertad 333', '3535128943'),
('Juana', 'Alassia', 'Villa Maria', 'Jujuy 4567', '3535345278'),
('Patricio', 'Arce', 'Villa Nueva', 'Marcos Juarez 1204', '3534675466');

SELECT * FROM Cliente;