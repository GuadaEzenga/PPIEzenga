const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',       
    user: 'root',           
    password: 'betuno123',   
    database: 'SoderiaDB',   
    port: 3306              
});

connection.connect((err) => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos SoderiaDB');
});

module.exports = connection;
