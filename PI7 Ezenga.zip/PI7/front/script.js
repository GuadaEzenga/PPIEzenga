document.addEventListener("DOMContentLoaded", () => {
    obtenerClientes(); 

    const form = document.getElementById("datosFormulario");
    form.addEventListener("submit", function (event) {
        event.preventDefault(); 
        agregarCliente(); 
    });
});

function obtenerClientes() {
    axios.get('http://localhost:3000/clientes')
        .then(response => {
            const clientes = response.data;
            const tableBody = document.getElementById("table_cliente");
            tableBody.innerHTML = ""; 

            clientes.forEach(cliente => {
                const row = document.createElement("tr");
                row.innerHTML = `
                    <td>${cliente.idCliente}</td>
                    <td>${cliente.nombre}</td>
                    <td>${cliente.apellido}</td>
                    <td>${cliente.telefono}</td>
                    <td>${cliente.ciudad}</td>
                    <td>${cliente.direccion}</td>
                    <td>
                        <button class="btn btn-warning" onclick="modificarDatos(${cliente.idCliente})">Modificar</button>
                        <button class="btn btn-danger" onclick="eliminarCliente(${cliente.idCliente})">Eliminar</button>
                        <button class="btn btn-info" onclick="consultarDatos(${cliente.idCliente})">Consultar</button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error("Error al obtener los clientes:", error);
        });
}

function actualizarCliente() {
    const idCliente = document.getElementById("idCliente").value;
    const cliente = {
        nombre: document.getElementById("nombre").value,
        apellido: document.getElementById("apellido").value,
        telefono: document.getElementById("telefono").value,
        ciudad: document.getElementById("ciudad").value,
        direccion: document.getElementById("direccion").value,
    };

    if (!idCliente) {
        alert("Seleccionar un registro");
        return;
    }
    if (!cliente.nombre || !cliente.apellido) {
        alert("Faltan completar datos");
        return;
    }

    axios.put(`http://localhost:3000/clientes/${idCliente}`, cliente)
        .then(response => {
            console.log(response);
            alert("Cliente actualizado");
            obtenerClientes(); 
            limpiarFormulario(); 
        })
        .catch(error => {
            console.error('Error al actualizar el cliente:', error);
        });
}


function agregarCliente(event) {
    event.preventDefault(); 

    const nuevoCliente = {
        nombre: document.getElementById('nombre').value,
        apellido: document.getElementById('apellido').value,
        telefono: document.getElementById('telefono').value,
        ciudad: document.getElementById('ciudad').value,
        direccion: document.getElementById('direccion').value
    };

    axios.post('http://localhost:3000/clientes', nuevoCliente)
        .then(response => {
            if (response.data) {
                agregarClienteATabla(response.data); 
            } else {
                console.error("No se recibió el cliente agregado.");
            }
            limpiarFormulario();
            location.reload(); 
        })
        .catch(error => {
            alert("Error al agregar el cliente: " + error.message); 
            console.error(error);
        });
}


function agregarClienteATabla(cliente) {
    const tableBody = document.getElementById('table_cliente');
    const newRow = document.createElement('tr');
    
    newRow.innerHTML = `
        <td>${cliente.idCliente}</td>
        <td>${cliente.nombre}</td>
        <td>${cliente.apellido}</td>
        <td>${cliente.telefono}</td>
        <td>${cliente.ciudad}</td>
        <td>${cliente.direccion}</td>
        <td>
            <button class="btn btn-warning" onclick="modificarDatos(${cliente.idCliente})">Modificar</button>
            <button class="btn btn-danger" onclick="eliminarCliente(${cliente.idCliente})">Eliminar</button>
            <button class="btn btn-info" onclick="consultarCliente(${cliente.idCliente})">Consultar</button>
        </td>
    `;
    
    tableBody.appendChild(newRow); 
}

function consultarDatos(id) {
    axios.get(`http://localhost:3000/clientes/${id}`)
        .then(response => {
            const cliente = response.data;
            document.getElementById("idCliente").value = cliente.idCliente;
            document.getElementById("nombre").value = cliente.nombre;
            document.getElementById("apellido").value = cliente.apellido;
            document.getElementById("telefono").value = cliente.telefono;
            document.getElementById("ciudad").value = cliente.ciudad;
            document.getElementById("direccion").value = cliente.direccion;

            document.getElementById('idCliente').setAttribute('readonly', true);
            document.getElementById('nombre').setAttribute('readonly', true);
            document.getElementById("apellido").setAttribute('readonly', true);
            document.getElementById("telefono").setAttribute('readonly', true);
            document.getElementById("ciudad").setAttribute('readonly', true);
            document.getElementById('direccion').setAttribute('readonly', true);

            document.getElementById('idCliente').readOnly = true;
            document.getElementById('btnAgregar').disabled = true;
            document.getElementById('btnActualizar').disabled = true;
        })
        .catch(error => {
            console.error("Error al consultar el cliente:", error);
        });
}

function limpiarFormulario() {
    location.reload(); 
}


function modificarDatos(id) {
    axios.get(`http://localhost:3000/clientes/${id}`)
        .then(response => {
            const cliente = response.data;
            document.getElementById("idCliente").value = cliente.idCliente;
            document.getElementById("nombre").value = cliente.nombre;
            document.getElementById("apellido").value = cliente.apellido;
            document.getElementById("telefono").value = cliente.telefono;
            document.getElementById("ciudad").value = cliente.ciudad;
            document.getElementById("direccion").value = cliente.direccion;

            document.getElementById("idCliente").disabled = true;
            document.getElementById("btnAgregar").disabled = true;
        })
        .catch(error => {
            console.error("Error al consultar el cliente:", error);
        });
}


function eliminarCliente(id) {
    if (confirm("¿Estás seguro de que deseas eliminar este cliente?")) {
        axios.delete(`http://localhost:3000/clientes/${id}`)
            .then(() => {
                alert("Cliente eliminado con éxito");
                obtenerClientes(); 
            })
            .catch(error => {
                console.error("Error al eliminar el cliente:", error);
            });
    }
}
