const db = require('../back/script');

const getAllUsers = (req, res) => {
    const sql = 'SELECT * FROM Cliente';
    db.query(sql, (err, result) => {
        if (err) {
            console.error('Error al consultar los clientes:', err);
            return res.status(500).json({ error: 'Error en la consulta' });
        }
        res.json(result);
    });
};

const createUser = (req, res) => {
    const { nombre, apellido, ciudad, direccion, telefono } = req.body;
    const sql = 'INSERT INTO Cliente (nombre, apellido, ciudad, direccion, telefono) VALUES (?, ?, ?, ?, ?)';
    db.query(sql, [nombre, apellido, ciudad, direccion, telefono], (err) => {
        if (err) {
            console.error('Error al agregar el cliente:', err);
            return res.status(500).json({ error: 'Error al agregar el cliente' });
        }
        res.json({ message: 'Cliente agregado' });
    });
};

const getUserById = (req, res) => {
    const sql = 'SELECT * FROM Cliente WHERE idCliente = ?';
    db.query(sql, [req.params.id], (err, result) => {
        if (err) {
            console.error('Error al consultar el cliente:', err);
            return res.status(500).json({ error: 'Error en la consulta' });
        }
        if (result.length === 0) {
            return res.status(404).json({ error: 'Cliente no encontrado' });
        }
        res.json(result[0]); 
    });
};

const deleteUser = (req, res) => {
    const sql = 'DELETE FROM Cliente WHERE idCliente = ?'; 
    db.query(sql, [req.params.id], (err) => {
        if (err) {
            console.error('Error al eliminar el cliente:', err);
            return res.status(500).json({ error: 'Error al eliminar el cliente' });
        }
        res.json({ message: 'Cliente eliminado' });
    });
};

const updateUser = (req, res) => {
    const { nombre, apellido, ciudad, direccion, telefono } = req.body; 
    const idCliente = req.params.id;

    if (!idCliente) {
        return res.status(400).json({ error: 'ID del cliente es requerido' });
    }

    const sql = 'UPDATE Cliente SET nombre = ?, apellido = ?, ciudad = ?, direccion = ?, telefono = ? WHERE idCliente = ?';
    db.query(sql, [nombre, apellido, ciudad, direccion, telefono, idCliente], (err) => {
        if (err) {
            console.error('Error al actualizar el cliente:', err);
            return res.status(500).json({ error: 'Error al actualizar el cliente' });
        }
        res.json({ message: 'Cliente actualizado' });
    });
};

module.exports = {
    getAllUsers,
    createUser,
    getUserById,
    deleteUser,
    updateUser,
};
